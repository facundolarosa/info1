#ifndef EMPAQUETAR_H_INCLUDED
#define EMPAQUETAR_H_INCLUDED

typedef struct
{
    unsigned char R;
    unsigned char G;
    unsigned char B;

} RGB_t;

int empaquetarRGB(RGB_t RGB);
RGB_t desempaquetarRGB(int RGB_int);

#endif // EMPAQUETAR_H_INCLUDED
