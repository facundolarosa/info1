#include <stdio.h>
#include <stdlib.h>
#include "empaquetar.h"

int main()
{
    RGB_t RGB;
    RGB_t RGB_2;

    int RGB_pack;

    RGB.R=0x30;
    RGB.G=0x20;
    RGB.B=0x10;

    RGB_pack=empaquetarRGB(RGB);

    printf("El valor de RGB es: %X",RGB_pack);

    RGB_2=desempaquetarRGB(RGB_pack);

    printf("\n\nEl valor de R es %hhx",RGB_2.R);
    printf("\n\nEl valor de G es %hhx",RGB_2.G);
    printf("\n\nEl valor de B es %hhx",RGB_2.B);
}
