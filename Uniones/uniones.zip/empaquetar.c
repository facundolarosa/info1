#ifndef EMPAQUETAR_C_INCLUDED
#define EMPAQUETAR_C_INCLUDED
#include "empaquetar.h"

typedef union
{
    int RGB_int;
    unsigned char RGB_vec[4];
} RGB_u;

int empaquetarRGB(RGB_t RGB)
{
    RGB_u RGB_union;

    RGB_union.RGB_vec[0]=RGB.B;
    RGB_union.RGB_vec[1]=RGB.G;
    RGB_union.RGB_vec[2]=RGB.R;
    RGB_union.RGB_vec[3]=0;

    return RGB_union.RGB_int;
}

RGB_t desempaquetarRGB(int RGB_int)
{
    RGB_u RGB_union;
    RGB_t RGB;

    RGB_union.RGB_int=RGB_int;

    RGB.B=RGB_union.RGB_vec[0];
    RGB.G=RGB_union.RGB_vec[1];
    RGB.R=RGB_union.RGB_vec[2];

    return RGB;
}
#endif // EMPAQUETAR_C_INCLUDED
